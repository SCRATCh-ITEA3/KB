<?php 
/**
 * Cons_req Page Controller
 * @category  Controller
 */
class Cons_reqController extends SecureController{
	function __construct(){
		parent::__construct();
		$this->tablename = "cons_req";
	}
	/**
     * List page records
     * @param $fieldname (filter record by a field) 
     * @param $fieldvalue (filter field value)
     * @return BaseView
     */
	function index($fieldname = null , $fieldvalue = null){
		$request = $this->request;
		$db = $this->GetModel();
		$tablename = $this->tablename;
		$fields = array("unique_nr", 
			"standard", 
			"type_req", 
			"req_nr", 
			"description", 
			"prim_keyw", 
			"threats");
		$pagination = $this->get_pagination(MAX_RECORD_COUNT); // get current pagination e.g array(page_number, page_limit)
		//search table record
		if(!empty($request->search)){
			$text = trim($request->search); 
			$search_condition = "(
				cons_req.unique_nr LIKE ? OR 
				cons_req.standard LIKE ? OR 
				cons_req.type_req LIKE ? OR 
				cons_req.req_nr LIKE ? OR 
				cons_req.description LIKE ? OR 
				cons_req.mandatory_l1 LIKE ? OR 
				cons_req.sec_class LIKE ? OR 
				cons_req.prim_keyw LIKE ? OR 
				cons_req.sec_keyw LIKE ? OR 
				cons_req.cat_nr LIKE ? OR 
				cons_req.iotsfmapetsi LIKE ? OR 
				cons_req.threats LIKE ? OR 
				cons_req.remarks LIKE ? OR 
				cons_req.ref_author LIKE ? OR 
				cons_req.ref_url LIKE ? OR 
				cons_req.licence LIKE ? OR 
				cons_req.level_2 LIKE ? OR 
				cons_req.level_3 LIKE ?
			)";
			$search_params = array(
				"%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%"
			);
			//setting search conditions
			$db->where($search_condition, $search_params);
			 //template to use when ajax search
			$this->view->search_template = "cons_req/search.php";
		}
		if(!empty($request->orderby)){
			$orderby = $request->orderby;
			$ordertype = (!empty($request->ordertype) ? $request->ordertype : ORDER_TYPE);
			$db->orderBy($orderby, $ordertype);
		}
		else{
			$db->orderBy("cons_req.unique_nr", ORDER_TYPE);
		}
		if($fieldname){
			$db->where($fieldname , $fieldvalue); //filter by a single field name
		}
		$tc = $db->withTotalCount();
		$records = $db->get($tablename, $pagination, $fields);
		$records_count = count($records);
		$total_records = intval($tc->totalCount);
		$page_limit = $pagination[1];
		$total_pages = ceil($total_records / $page_limit);
		$data = new stdClass;
		$data->records = $records;
		$data->record_count = $records_count;
		$data->total_records = $total_records;
		$data->total_page = $total_pages;
		if($db->getLastError()){
			$this->set_page_error();
		}
		$page_title = $this->view->page_title = get_lang('cons_req');
		$this->view->report_filename = date('Y-m-d') . '-' . $page_title;
		$this->view->report_title = $page_title;
		$this->view->report_layout = "report_layout.php";
		$this->view->report_paper_size = "A4";
		$this->view->report_orientation = "portrait";
		$view_name = (is_ajax() ? "cons_req/ajax-list.php" : "cons_req/list.php");
		$this->render_view($view_name, $data);
	}
	/**
     * View record detail 
	 * @param $rec_id (select record by table primary key) 
     * @param $value value (select record by value of field name(rec_id))
     * @return BaseView
     */
	function view($rec_id = null, $value = null){
		$request = $this->request;
		$db = $this->GetModel();
		$rec_id = $this->rec_id = urldecode($rec_id);
		$tablename = $this->tablename;
		$fields = array("unique_nr", 
			"standard", 
			"type_req", 
			"req_nr", 
			"description", 
			"mandatory_l1", 
			"sec_class", 
			"prim_keyw", 
			"sec_keyw", 
			"cat_nr", 
			"iotsfmapetsi", 
			"threats", 
			"remarks", 
			"ref_author", 
			"ref_url", 
			"licence", 
			"level_2", 
			"level_3");
		if($value){
			$db->where($rec_id, urldecode($value)); //select record based on field name
		}
		else{
			$db->where("cons_req.unique_nr", $rec_id);; //select record based on primary key
		}
		$record = $db->getOne($tablename, $fields );
		if($record){
			$page_title = $this->view->page_title = get_lang('view_cons_req');
		$this->view->report_filename = date('Y-m-d') . '-' . $page_title;
		$this->view->report_title = $page_title;
		$this->view->report_layout = "report_layout.php";
		$this->view->report_paper_size = "A4";
		$this->view->report_orientation = "portrait";
		}
		else{
			if($db->getLastError()){
				$this->set_page_error();
			}
			else{
				$this->set_page_error(get_lang('no_record_found'));
			}
		}
		return $this->render_view("cons_req/view.php", $record);
	}
	/**
     * Update single field
	 * @param $rec_id (select record by table primary key)
	 * @param $formdata array() from $_POST
     * @return array
     */
	function editfield($rec_id = null, $formdata = null){
		$db = $this->GetModel();
		$this->rec_id = $rec_id;
		$tablename = $this->tablename;
		//editable fields
		$fields = $this->fields = array("unique_nr","standard","type_req","req_nr","description","mandatory_l1","sec_class","prim_keyw","sec_keyw","cat_nr","iotsfmapetsi","threats","remarks","ref_author","ref_url","licence","level_2","level_3");
		$page_error = null;
		if($formdata){
			$postdata = array();
			$fieldname = $formdata['name'];
			$fieldvalue = $formdata['value'];
			$postdata[$fieldname] = $fieldvalue;
			$postdata = $this->format_request_data($postdata);
			$this->rules_array = array(
				'sec_class' => 'numeric',
			);
			$this->sanitize_array = array(
				'standard' => 'sanitize_string',
				'type_req' => 'sanitize_string',
				'req_nr' => 'sanitize_string',
				'description' => 'sanitize_string',
				'mandatory_l1' => 'sanitize_string',
				'sec_class' => 'sanitize_string',
				'prim_keyw' => 'sanitize_string',
				'sec_keyw' => 'sanitize_string',
				'cat_nr' => 'sanitize_string',
				'iotsfmapetsi' => 'sanitize_string',
				'threats' => 'sanitize_string',
				'remarks' => 'sanitize_string',
				'ref_author' => 'sanitize_string',
				'ref_url' => 'sanitize_string',
				'licence' => 'sanitize_string',
				'level_2' => 'sanitize_string',
				'level_3' => 'sanitize_string',
			);
			$this->filter_rules = true; //filter validation rules by excluding fields not in the formdata
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			if($this->validated()){
				$db->where("cons_req.unique_nr", $rec_id);;
				$bool = $db->update($tablename, $modeldata);
				$numRows = $db->getRowCount();
				if($bool && $numRows){
					return render_json(
						array(
							'num_rows' =>$numRows,
							'rec_id' =>$rec_id,
						)
					);
				}
				else{
					if($db->getLastError()){
						$page_error = $db->getLastError();
					}
					elseif(!$numRows){
						$page_error = get_lang('no_record_updated');
					}
					render_error($page_error);
				}
			}
			else{
				render_error($this->view->page_error);
			}
		}
		return null;
	}
}
