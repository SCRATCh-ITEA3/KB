<?php 

/**
 * SharedController Controller
 * @category  Controller / Model
 */
class SharedController extends BaseController{
	
	/**
     * scratch_requirement_tags_goodpractices_option_list Model Action
     * @return array
     */
	function scratch_requirement_tags_goodpractices_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT good_practice AS value,good_practice AS label FROM enisa_good_practices";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * scratch_requirement_sebok_c_option_list Model Action
     * @return array
     */
	function scratch_requirement_sebok_c_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT sebok_c AS value,sebok_c AS label FROM sebok_c";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * user_auth_user_role_id_option_list Model Action
     * @return array
     */
	function user_auth_user_role_id_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT role_id AS value, role_name AS label FROM roles";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * user_auth_name_value_exist Model Action
     * @return array
     */
	function user_auth_name_value_exist($val){
		$db = $this->GetModel();
		$db->where("name", $val);
		$exist = $db->has("user_auth");
		return $exist;
	}

	/**
     * user_auth_email_value_exist Model Action
     * @return array
     */
	function user_auth_email_value_exist($val){
		$db = $this->GetModel();
		$db->where("email", $val);
		$exist = $db->has("user_auth");
		return $exist;
	}

	/**
     * dcms_web_link_option_list Model Action
     * @return array
     */
	function dcms_web_link_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT DISTINCT Organisation AS value , Standard_Recommendation_Name AS label FROM dcms ORDER BY label ASC";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * dcm_owasp_top10_map_dcm_nr_option_list Model Action
     * @return array
     */
	function dcm_owasp_top10_map_dcm_nr_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT DISTINCT DCMS_Code_Practice AS value , Standard_Recommendation_Name AS label FROM dcms ORDER BY label ASC";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * dcms_all_org_Organisation_option_list Model Action
     * @return array
     */
	function dcms_all_org_Organisation_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT DISTINCT Organisation AS value , Standard_Recommendation_Name AS label FROM dcms_all_org ORDER BY label ASC";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * dcms_code_dcm_link_option_list Model Action
     * @return array
     */
	function dcms_code_dcm_link_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT DISTINCT nr AS value , nr AS label FROM owasp_top10 ORDER BY label ASC";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * dcms_code_dcm_nr_option_list Model Action
     * @return array
     */
	function dcms_code_dcm_nr_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT DISTINCT dcm_nr AS value , dcm_nr AS label FROM test_map ORDER BY label ASC";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * dcms_code_test_map_owasp_nr_option_list Model Action
     * @return array
     */
	function dcms_code_test_map_owasp_nr_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT nr AS value,description AS label FROM owasp_top10 ORDER BY nr ASC";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * dcms_code_test_map_dcm_nr_option_list Model Action
     * @return array
     */
	function dcms_code_test_map_dcm_nr_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT dcm_nr AS value,dcm_descr AS label FROM dcms_code ORDER BY dcm_nr ASC";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * test_map_dcm_nr_option_list Model Action
     * @return array
     */
	function test_map_dcm_nr_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT dcm_nr AS value,dcm_descr AS label FROM dcms_code ORDER BY dcm_nr ASC";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * test_map_owasp_nr_option_list Model Action
     * @return array
     */
	function test_map_owasp_nr_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT nr AS value,description AS label FROM owasp_top10 ORDER BY nr ASC";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * iot_a_uni_iot_a_unireq_type_option_list Model Action
     * @return array
     */
	function iot_a_uni_iot_a_unireq_type_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT req_type AS value,req_type AS label FROM iot_a_uni ORDER BY uni_id";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * dcms_dcmsDCMS_Code_Practice_option_list Model Action
     * @return array
     */
	function dcms_dcmsDCMS_Code_Practice_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT dcm_nr AS value,dcm_descr AS label FROM dcms_code ORDER BY dcm_descr ASC";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * dcms_dcmsOrganisation_option_list Model Action
     * @return array
     */
	function dcms_dcmsOrganisation_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT Organisation AS value,Organisation AS label FROM dcms ORDER BY Organisation ASC";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * getcount_dcmscode Model Action
     * @return Value
     */
	function getcount_dcmscode(){
		$db = $this->GetModel();
		$sqltext = "SELECT  tm.owasp_nr, tm.dcm_nr, dc.dcm_nr, dc.dcm_descr, dc.dcm_expl, dc.dcm_expl2, dc.dcm_link FROM test_map AS tm JOIN dcms_code AS dc ON tm.dcm_nr=dc.dcm_nr";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_requirementscollectionfromstandards Model Action
     * @return Value
     */
	function getcount_requirementscollectionfromstandards(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM cons_req";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_overviewoforganisationsandstandards Model Action
     * @return Value
     */
	function getcount_overviewoforganisationsandstandards(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM dcms";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_dcmsallorg Model Action
     * @return Value
     */
	function getcount_dcmsallorg(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM dcms_all_org";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_enisaindustryiot Model Action
     * @return Value
     */
	function getcount_enisaindustryiot(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM enisa_industry_iot";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_iotsfreqv2 Model Action
     * @return Value
     */
	function getcount_iotsfreqv2(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM iotsf_req_v2";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_owaspisvs10rc Model Action
     * @return Value
     */
	function getcount_owaspisvs10rc(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM owasp_isvs_1_0rc";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

}
