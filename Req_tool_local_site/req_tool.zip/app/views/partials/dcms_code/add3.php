<?php
$comp_model = new SharedController;
$page_element_id = "add-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
$show_header = $this->show_header;
$view_title = $this->view_title;
$redirect_to = $this->redirect_to;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="add"  data-display-type="" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title"><?php print_lang('add_new_dcms_code'); ?></h4>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <div  class="">
        <div class="container">
            <div class="row ">
                <div class="col-md-7 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="bg-light p-3 animated fadeIn page-content">
                        <form id="dcms_code-add3-form"  novalidate role="form" enctype="multipart/form-data" class="form multi-form page-form" action="<?php print_link("dcms_code/add3?csrf_token=$csrf_token") ?>" method="post" >
                            <div>
                                <table class="table table-striped table-sm" data-maxrow="10" data-minrow="1">
                                    <thead>
                                        <tr>
                                            <th class="bg-light"><label for="dcm_descr"><?php print_lang('dcm_descr'); ?></label></th>
                                            <th class="bg-light"><label for="dcm_expl"><?php print_lang('dcm_expl'); ?></label></th>
                                            <th class="bg-light"><label for="dcm_expl2"><?php print_lang('dcm_expl2'); ?></label></th>
                                            <th class="bg-light"><label for="dcm_link"><?php print_lang('dcm_link'); ?></label></th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        for( $row = 1; $row <= 1; $row++ ){
                                        ?>
                                        <tr class="input-row">
                                            <td>
                                                <div id="ctrl-dcm_descr-row<?php echo $row; ?>-holder" class="">
                                                    <input id="ctrl-dcm_descr-row<?php echo $row; ?>"  value="<?php  echo $this->set_field_value('dcm_descr',"", $row); ?>" type="text" placeholder="<?php print_lang('enter_dcm_descr'); ?>"  name="row<?php echo $row ?>[dcm_descr]"  class="form-control " />
                                                    </div>
                                                </td>
                                                <td>
                                                    <div id="ctrl-dcm_expl-row<?php echo $row; ?>-holder" class="">
                                                        <textarea placeholder="<?php print_lang('enter_dcm_expl'); ?>" id="ctrl-dcm_expl-row<?php echo $row; ?>"  rows="5" name="row<?php echo $row ?>[dcm_expl]" class=" form-control"><?php  echo $this->set_field_value('dcm_expl',"", $row); ?></textarea>
                                                        <!--<div class="invalid-feedback animated bounceIn text-center"><?php print_lang('please_enter_text'); ?></div>-->
                                                    </div>
                                                </td>
                                                <td>
                                                    <div id="ctrl-dcm_expl2-row<?php echo $row; ?>-holder" class="">
                                                        <textarea placeholder="<?php print_lang('enter_dcm_expl2'); ?>" id="ctrl-dcm_expl2-row<?php echo $row; ?>"  rows="5" name="row<?php echo $row ?>[dcm_expl2]" class=" form-control"><?php  echo $this->set_field_value('dcm_expl2',"", $row); ?></textarea>
                                                        <!--<div class="invalid-feedback animated bounceIn text-center"><?php print_lang('please_enter_text'); ?></div>-->
                                                    </div>
                                                </td>
                                                <td>
                                                    <div id="ctrl-dcm_link-row<?php echo $row; ?>-holder" class="">
                                                        <input id="ctrl-dcm_link-row<?php echo $row; ?>"  value="<?php  echo $this->set_field_value('dcm_link',"", $row); ?>" type="text" placeholder="<?php print_lang('enter_dcm_link'); ?>"  name="row<?php echo $row ?>[dcm_link]"  class="form-control " />
                                                        </div>
                                                    </td>
                                                    <th class="text-center">
                                                        <button type="button" class="close btn-remove-table-row">&times;</button>
                                                    </th>
                                                </tr>
                                                <?php 
                                                }
                                                ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th colspan="100" class="text-right">
                                                        <?php $template_id = "table-row-" . random_str(); ?>
                                                        <button type="button" data-template="#<?php echo $template_id ?>" class="btn btn-sm btn-light btn-add-table-row"><i class="fa fa-plus"></i></button>
                                                    </th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                    <div class="bg-light p-2 subform">
                                        <h4 class="record-title">Add New Dcms Code</h4>
                                        <hr />
                                        <div>
                                            <table class="table table-striped table-sm" data-maxrow="10" data-minrow="1">
                                                <thead>
                                                    <tr>
                                                        <th class="bg-light"><label for="dcm_descr"><?php print_lang('dcm_descr'); ?></label></th>
                                                        <th class="bg-light"><label for="dcm_expl"><?php print_lang('dcm_expl'); ?></label></th>
                                                        <th class="bg-light"><label for="dcm_expl2"><?php print_lang('dcm_expl2'); ?></label></th>
                                                        <th class="bg-light"><label for="dcm_link"><?php print_lang('dcm_link'); ?></label></th>
                                                        <th></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    for( $row = 1; $row <= 1; $row++ ){
                                                    ?>
                                                    <tr class="input-row">
                                                        <td>
                                                            <div id="ctrl-dcm_descr-row<?php echo $row; ?>-holder" class="">
                                                                <input id="ctrl-dcm_descr-row<?php echo $row; ?>"  value="<?php  echo $this->set_field_value('dcm_descr',"", $row); ?>" type="text" placeholder="<?php print_lang('enter_dcm_descr'); ?>"  name="dcms_code[row<?php echo $row ?>][dcm_descr]"  class="form-control " />
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div id="ctrl-dcm_expl-row<?php echo $row; ?>-holder" class="">
                                                                    <textarea placeholder="<?php print_lang('enter_dcm_expl'); ?>" id="ctrl-dcm_expl-row<?php echo $row; ?>"  rows="5" name="dcms_code[row<?php echo $row ?>][dcm_expl]" class=" form-control"><?php  echo $this->set_field_value('dcm_expl',"", $row); ?></textarea>
                                                                    <!--<div class="invalid-feedback animated bounceIn text-center">[html-lang-0130]</div>-->
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div id="ctrl-dcm_expl2-row<?php echo $row; ?>-holder" class="">
                                                                    <textarea placeholder="<?php print_lang('enter_dcm_expl2'); ?>" id="ctrl-dcm_expl2-row<?php echo $row; ?>"  rows="5" name="dcms_code[row<?php echo $row ?>][dcm_expl2]" class=" form-control"><?php  echo $this->set_field_value('dcm_expl2',"", $row); ?></textarea>
                                                                    <!--<div class="invalid-feedback animated bounceIn text-center">[html-lang-0130]</div>-->
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div id="ctrl-dcm_link-row<?php echo $row; ?>-holder" class="">
                                                                    <input id="ctrl-dcm_link-row<?php echo $row; ?>"  value="<?php  echo $this->set_field_value('dcm_link',"", $row); ?>" type="text" placeholder="<?php print_lang('enter_dcm_link'); ?>"  name="dcms_code[row<?php echo $row ?>][dcm_link]"  class="form-control " />
                                                                    </div>
                                                                </td>
                                                                <th class="text-center">
                                                                    <button type="button" class="close btn-remove-table-row">&times;</button>
                                                                </th>
                                                            </tr>
                                                            <?php 
                                                            }
                                                            ?>
                                                        </tbody>
                                                        <tfoot>
                                                            <tr>
                                                                <th colspan="100" class="text-right">
                                                                    <?php $template_id = "table-row-" . random_str(); ?>
                                                                    <button type="button" data-template="#<?php echo $template_id ?>" class="btn btn-sm btn-light btn-add-table-row"><i class="fa fa-plus"></i></button>
                                                                </th>
                                                            </tr>
                                                        </tfoot>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="form-group form-submit-btn-holder text-center mt-3">
                                                <div class="form-ajax-status"></div>
                                                <button class="btn btn-primary" type="submit">
                                                    <?php print_lang('submit'); ?>
                                                    <i class="fa fa-send"></i>
                                                </button>
                                            </div>
                                            </form><template id="<?php echo $template_id ?>">
                                            <tr class="input-row">
                                                <?php $row = 1; ?>
                                                <td>
                                                    <div id="ctrl-dcm_descr-row<?php echo $row; ?>-holder" class="">
                                                        <input id="ctrl-dcm_descr-row<?php echo $row; ?>"  value="<?php  echo $this->set_field_value('dcm_descr',"", $row); ?>" type="text" placeholder="<?php print_lang('enter_dcm_descr'); ?>"  name="dcms_code[row<?php echo $row ?>][dcm_descr]"  class="form-control " />
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div id="ctrl-dcm_expl-row<?php echo $row; ?>-holder" class="">
                                                            <textarea placeholder="<?php print_lang('enter_dcm_expl'); ?>" id="ctrl-dcm_expl-row<?php echo $row; ?>"  rows="5" name="dcms_code[row<?php echo $row ?>][dcm_expl]" class=" form-control"><?php  echo $this->set_field_value('dcm_expl',"", $row); ?></textarea>
                                                            <!--<div class="invalid-feedback animated bounceIn text-center">[html-lang-0130]</div>-->
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div id="ctrl-dcm_expl2-row<?php echo $row; ?>-holder" class="">
                                                            <textarea placeholder="<?php print_lang('enter_dcm_expl2'); ?>" id="ctrl-dcm_expl2-row<?php echo $row; ?>"  rows="5" name="dcms_code[row<?php echo $row ?>][dcm_expl2]" class=" form-control"><?php  echo $this->set_field_value('dcm_expl2',"", $row); ?></textarea>
                                                            <!--<div class="invalid-feedback animated bounceIn text-center">[html-lang-0130]</div>-->
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div id="ctrl-dcm_link-row<?php echo $row; ?>-holder" class="">
                                                            <input id="ctrl-dcm_link-row<?php echo $row; ?>"  value="<?php  echo $this->set_field_value('dcm_link',"", $row); ?>" type="text" placeholder="<?php print_lang('enter_dcm_link'); ?>"  name="dcms_code[row<?php echo $row ?>][dcm_link]"  class="form-control " />
                                                            </div>
                                                        </td>
                                                        <th class="text-center">
                                                            <button type="button" class="close btn-remove-table-row">&times;</button>
                                                        </th>
                                                    </tr>
                                                </template>
                                                <!--[table row template]-->
                                                <template id="<?php echo $template_id ?>">
                                                    <tr class="input-row">
                                                        <?php $row = 1; ?>
                                                        <td>
                                                            <div id="ctrl-dcm_descr-row<?php echo $row; ?>-holder" class="">
                                                                <input id="ctrl-dcm_descr-row<?php echo $row; ?>"  value="<?php  echo $this->set_field_value('dcm_descr',"", $row); ?>" type="text" placeholder="<?php print_lang('enter_dcm_descr'); ?>"  name="row<?php echo $row ?>[dcm_descr]"  class="form-control " />
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div id="ctrl-dcm_expl-row<?php echo $row; ?>-holder" class="">
                                                                    <textarea placeholder="<?php print_lang('enter_dcm_expl'); ?>" id="ctrl-dcm_expl-row<?php echo $row; ?>"  rows="5" name="row<?php echo $row ?>[dcm_expl]" class=" form-control"><?php  echo $this->set_field_value('dcm_expl',"", $row); ?></textarea>
                                                                    <!--<div class="invalid-feedback animated bounceIn text-center"><?php print_lang('please_enter_text'); ?></div>-->
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div id="ctrl-dcm_expl2-row<?php echo $row; ?>-holder" class="">
                                                                    <textarea placeholder="<?php print_lang('enter_dcm_expl2'); ?>" id="ctrl-dcm_expl2-row<?php echo $row; ?>"  rows="5" name="row<?php echo $row ?>[dcm_expl2]" class=" form-control"><?php  echo $this->set_field_value('dcm_expl2',"", $row); ?></textarea>
                                                                    <!--<div class="invalid-feedback animated bounceIn text-center"><?php print_lang('please_enter_text'); ?></div>-->
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div id="ctrl-dcm_link-row<?php echo $row; ?>-holder" class="">
                                                                    <input id="ctrl-dcm_link-row<?php echo $row; ?>"  value="<?php  echo $this->set_field_value('dcm_link',"", $row); ?>" type="text" placeholder="<?php print_lang('enter_dcm_link'); ?>"  name="row<?php echo $row ?>[dcm_link]"  class="form-control " />
                                                                    </div>
                                                                </td>
                                                                <th class="text-center">
                                                                    <button type="button" class="close btn-remove-table-row">&times;</button>
                                                                </th>
                                                            </tr>
                                                        </template>
                                                        <!--[/table row template]-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
