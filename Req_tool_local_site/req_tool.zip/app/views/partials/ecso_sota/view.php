<?php
$comp_model = new SharedController;
$page_element_id = "view-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data Information from Controller
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id; //Page id from url
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_edit_btn = $this->show_edit_btn;
$show_delete_btn = $this->show_delete_btn;
$show_export_btn = $this->show_export_btn;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="view"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title"><?php print_lang('view_ecso_sota'); ?></h4>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <div  class="">
        <div class="container">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="card animated fadeIn page-content">
                        <?php
                        $counter = 0;
                        if(!empty($data)){
                        $rec_id = (!empty($data['esco_id']) ? urlencode($data['esco_id']) : null);
                        $counter++;
                        ?>
                        <div id="page-report-body" class="">
                            <table class="table table-hover table-borderless table-striped">
                                <!-- Table Body Start -->
                                <tbody class="page-data" id="page-data-<?php echo $page_element_id; ?>">
                                    <tr  class="td-esco_id">
                                        <th class="title"> <?php print_lang('esco_id'); ?>: </th>
                                        <td class="value"> <?php echo $data['esco_id']; ?></td>
                                    </tr>
                                    <tr  class="td-standard_scheme">
                                        <th class="title"> <?php print_lang('standard_scheme'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['standard_scheme']; ?>" 
                                                data-pk="<?php echo $data['esco_id'] ?>" 
                                                data-url="<?php print_link("ecso_sota/editfield/" . urlencode($data['esco_id'])); ?>" 
                                                data-name="standard_scheme" 
                                                data-title="Enter Standard Scheme" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['standard_scheme']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-Body">
                                        <th class="title"> <?php print_lang('body'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['Body']; ?>" 
                                                data-pk="<?php echo $data['esco_id'] ?>" 
                                                data-url="<?php print_link("ecso_sota/editfield/" . urlencode($data['esco_id'])); ?>" 
                                                data-name="Body" 
                                                data-title="Enter Body" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['Body']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-Country_Industry">
                                        <th class="title"> <?php print_lang('country_industry'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['Country_Industry']; ?>" 
                                                data-pk="<?php echo $data['esco_id'] ?>" 
                                                data-url="<?php print_link("ecso_sota/editfield/" . urlencode($data['esco_id'])); ?>" 
                                                data-name="Country_Industry" 
                                                data-title="Enter Country Industry" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['Country_Industry']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-link">
                                        <th class="title"> <?php print_lang('link'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['link']; ?>" 
                                                data-pk="<?php echo $data['esco_id'] ?>" 
                                                data-url="<?php print_link("ecso_sota/editfield/" . urlencode($data['esco_id'])); ?>" 
                                                data-name="link" 
                                                data-title="Enter Link" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['link']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-Reference">
                                        <th class="title"> <?php print_lang('reference'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['Reference']; ?>" 
                                                data-pk="<?php echo $data['esco_id'] ?>" 
                                                data-url="<?php print_link("ecso_sota/editfield/" . urlencode($data['esco_id'])); ?>" 
                                                data-name="Reference" 
                                                data-title="Enter Reference" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['Reference']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-SWG">
                                        <th class="title"> <?php print_lang('swg'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['SWG']; ?>" 
                                                data-pk="<?php echo $data['esco_id'] ?>" 
                                                data-url="<?php print_link("ecso_sota/editfield/" . urlencode($data['esco_id'])); ?>" 
                                                data-name="SWG" 
                                                data-title="Enter Swg" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['SWG']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-sector_category">
                                        <th class="title"> <?php print_lang('sector_category'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['sector_category']; ?>" 
                                                data-pk="<?php echo $data['esco_id'] ?>" 
                                                data-url="<?php print_link("ecso_sota/editfield/" . urlencode($data['esco_id'])); ?>" 
                                                data-name="sector_category" 
                                                data-title="Enter Sector Category" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['sector_category']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-usecase_applicable">
                                        <th class="title"> <?php print_lang('usecase_applicable'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['usecase_applicable']; ?>" 
                                                data-pk="<?php echo $data['esco_id'] ?>" 
                                                data-url="<?php print_link("ecso_sota/editfield/" . urlencode($data['esco_id'])); ?>" 
                                                data-name="usecase_applicable" 
                                                data-title="Enter Usecase Applicable" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['usecase_applicable']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                                <!-- Table Body End -->
                            </table>
                        </div>
                        <div class="p-3 d-flex">
                            <div class="dropup export-btn-holder mx-1">
                                <button class="btn btn-sm btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fa fa-save"></i> <?php print_lang('export'); ?>
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <?php $export_print_link = $this->set_current_page_link(array('format' => 'print')); ?>
                                    <a class="dropdown-item export-link-btn" data-format="print" href="<?php print_link($export_print_link); ?>" target="_blank">
                                        <img src="<?php print_link('assets/images/print.png') ?>" class="mr-2" /> PRINT
                                        </a>
                                        <?php $export_pdf_link = $this->set_current_page_link(array('format' => 'pdf')); ?>
                                        <a class="dropdown-item export-link-btn" data-format="pdf" href="<?php print_link($export_pdf_link); ?>" target="_blank">
                                            <img src="<?php print_link('assets/images/pdf.png') ?>" class="mr-2" /> PDF
                                            </a>
                                            <?php $export_word_link = $this->set_current_page_link(array('format' => 'word')); ?>
                                            <a class="dropdown-item export-link-btn" data-format="word" href="<?php print_link($export_word_link); ?>" target="_blank">
                                                <img src="<?php print_link('assets/images/doc.png') ?>" class="mr-2" /> WORD
                                                </a>
                                                <?php $export_csv_link = $this->set_current_page_link(array('format' => 'csv')); ?>
                                                <a class="dropdown-item export-link-btn" data-format="csv" href="<?php print_link($export_csv_link); ?>" target="_blank">
                                                    <img src="<?php print_link('assets/images/csv.png') ?>" class="mr-2" /> CSV
                                                    </a>
                                                    <?php $export_excel_link = $this->set_current_page_link(array('format' => 'excel')); ?>
                                                    <a class="dropdown-item export-link-btn" data-format="excel" href="<?php print_link($export_excel_link); ?>" target="_blank">
                                                        <img src="<?php print_link('assets/images/xsl.png') ?>" class="mr-2" /> EXCEL
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                            }
                                            else{
                                            ?>
                                            <!-- Empty Record Message -->
                                            <div class="text-muted p-3">
                                                <i class="fa fa-ban"></i> <?php print_lang('no_record_found'); ?>
                                            </div>
                                            <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
