<?php 
$page_id = null;
$comp_model = new SharedController;
$current_page = $this->set_current_page_link();
?>
<div>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="page-header"><h4>Knowledge Base</h4></div>
            <div class="row ">
                <div class="col-md-12 comp-grid">
                </div>
                <div class="col-sm-6 comp-grid">
                    <?php $rec_count = $comp_model->getcount_requirementscollectionfromstandards();  ?>
                    <a class="animated zoomIn record-count card bg-light text-dark"  href="<?php print_link("cons_req/") ?>">
                        <div class="row">
                            <div class="col-2">
                                <i class="fa fa-globe"></i>
                            </div>
                            <div class="col-10">
                                <div class="flex-column justify-content align-center">
                                    <div class="title">requirements collection from standards</div>
                                    <small class=""></small>
                                </div>
                            </div>
                            <h4 class="value"><strong><?php echo $rec_count; ?></strong></h4>
                        </div>
                    </a>
                    <h6 ><?php print_lang('use_search_to_find_requirements_related_to_a_certain_keyword_e_g_authentication'); ?></h6>
                </div>
                <div class="col-sm-6 comp-grid">
                    <?php $rec_count = $comp_model->getcount_overviewoforganisationsandstandards();  ?>
                    <a class="animated zoomIn record-count card bg-light text-dark"  href="<?php print_link("dcms/filter") ?>">
                        <div class="row">
                            <div class="col-2">
                                <i class="fa fa-globe"></i>
                            </div>
                            <div class="col-10">
                                <div class="flex-column justify-content align-center">
                                    <div class="title">Overview of Organisations and standards</div>
                                    <small class=""></small>
                                </div>
                            </div>
                            <h4 class="value"><strong><?php echo $rec_count; ?></strong></h4>
                        </div>
                    </a>
                    <h5 ><?php print_lang('making_sense_of_global_iot_recommendations_and_standards_and_mapping_them_to_the_uk_s_code_of_practice_for_consumer_iot_security'); ?></h5>
                </div>
                <div class="col-md-6 comp-grid">
                    <?php $rec_count = $comp_model->getcount_dcmsallorg();  ?>
                    <a class="animated zoomIn record-count card bg-light text-dark"  href="<?php print_link("dcms_all_org/") ?>">
                        <div class="row">
                            <div class="col-2">
                                <i class="fa fa-globe"></i>
                            </div>
                            <div class="col-10">
                                <div class="flex-column justify-content align-center">
                                    <div class="title">Dcms All Org</div>
                                    <small class=""></small>
                                </div>
                            </div>
                            <h4 class="value"><strong><?php echo $rec_count; ?></strong></h4>
                        </div>
                    </a>
                    <h4 ><?php print_lang('organisations_governmental_standards_certification'); ?></h4>
                </div>
                <div class="col-md-6 comp-grid">
                    <?php $rec_count = $comp_model->getcount_enisaindustryiot();  ?>
                    <a class="animated zoomIn record-count card bg-light text-dark"  href="<?php print_link("enisa_industry_iot/") ?>">
                        <div class="row">
                            <div class="col-2">
                                <i class="fa fa-globe"></i>
                            </div>
                            <div class="col-10">
                                <div class="flex-column justify-content align-center">
                                    <div class="title">Enisa Industry Iot</div>
                                    <small class=""></small>
                                </div>
                            </div>
                            <h4 class="value"><strong><?php echo $rec_count; ?></strong></h4>
                        </div>
                    </a>
                    <h4 ><?php print_lang('enisa_industry_iot'); ?></h4>
                </div>
                <div class="col-md-6 comp-grid">
                    <?php $rec_count = $comp_model->getcount_iotsfreqv2();  ?>
                    <a class="animated zoomIn record-count card bg-light text-dark"  href="<?php print_link("iotsf_req_v2/") ?>">
                        <div class="row">
                            <div class="col-2">
                                <i class="fa fa-globe"></i>
                            </div>
                            <div class="col-10">
                                <div class="flex-column justify-content align-center">
                                    <div class="title">Iotsf Req V2</div>
                                    <small class=""></small>
                                </div>
                            </div>
                            <h4 class="value"><strong><?php echo $rec_count; ?></strong></h4>
                        </div>
                    </a>
                    <h4 ><?php print_lang('iotsf'); ?></h4>
                </div>
                <div class="col-md-6 comp-grid">
                    <?php $rec_count = $comp_model->getcount_owaspisvs10rc();  ?>
                    <a class="animated zoomIn record-count card bg-light text-dark"  href="<?php print_link("owasp_isvs_1_0rc/") ?>">
                        <div class="row">
                            <div class="col-2">
                                <i class="fa fa-globe"></i>
                            </div>
                            <div class="col-10">
                                <div class="flex-column justify-content align-center">
                                    <div class="title">Owasp Isvs 1 0Rc</div>
                                    <small class=""></small>
                                </div>
                            </div>
                            <h4 class="value"><strong><?php echo $rec_count; ?></strong></h4>
                        </div>
                    </a>
                    <h4 ><?php print_lang('owasp_isvs_iot_testing_requirements'); ?></h4>
                </div>
            </div>
        </div>
    </div>
</div>
