<?php
$comp_model = new SharedController;
$page_element_id = "add-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
$show_header = $this->show_header;
$view_title = $this->view_title;
$redirect_to = $this->redirect_to;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="add"  data-display-type="" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title"><?php print_lang('add_new_dcms'); ?></h4>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <div  class="">
        <div class="container">
            <div class="row ">
                <div class="col-md-7 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="bg-light p-3 animated fadeIn page-content">
                        <form id="dcms-add-form" role="form" novalidate enctype="multipart/form-data" class="form page-form form-horizontal needs-validation" action="<?php print_link("dcms/add?csrf_token=$csrf_token") ?>" method="post">
                            <div>
                                <div class="form-group ">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <label class="control-label" for="main_cat"><?php print_lang('main_cat'); ?> </label>
                                        </div>
                                        <div class="col-sm-8">
                                            <div class="">
                                                <input id="ctrl-main_cat"  value="<?php  echo $this->set_field_value('main_cat',""); ?>" type="text" placeholder="<?php print_lang('enter_main_cat'); ?>"  name="main_cat"  class="form-control " />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label class="control-label" for="DCMS_Code_Practice"><?php print_lang('dcms_code_practice'); ?> </label>
                                            </div>
                                            <div class="col-sm-8">
                                                <div class="">
                                                    <input id="ctrl-DCMS_Code_Practice"  value="<?php  echo $this->set_field_value('DCMS_Code_Practice',""); ?>" type="number" placeholder="<?php print_lang('enter_dcms_code_practice'); ?>" step="1"  name="DCMS_Code_Practice"  class="form-control " />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <div class="row">
                                                <div class="col-sm-4">
                                                    <label class="control-label" for="Organisation"><?php print_lang('organisation'); ?> </label>
                                                </div>
                                                <div class="col-sm-8">
                                                    <div class="">
                                                        <input id="ctrl-Organisation"  value="<?php  echo $this->set_field_value('Organisation',""); ?>" type="text" placeholder="<?php print_lang('enter_organisation'); ?>"  name="Organisation"  class="form-control " />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group ">
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <label class="control-label" for="Standard_Recommendation_Name"><?php print_lang('standard_recommendation_name'); ?> </label>
                                                    </div>
                                                    <div class="col-sm-8">
                                                        <div class="">
                                                            <input id="ctrl-Standard_Recommendation_Name"  value="<?php  echo $this->set_field_value('Standard_Recommendation_Name',""); ?>" type="text" placeholder="<?php print_lang('enter_standard_recommendation_name'); ?>"  name="Standard_Recommendation_Name"  class="form-control " />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group ">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <label class="control-label" for="Recomm_number_section"><?php print_lang('recomm_number_section'); ?> </label>
                                                        </div>
                                                        <div class="col-sm-8">
                                                            <div class="">
                                                                <input id="ctrl-Recomm_number_section"  value="<?php  echo $this->set_field_value('Recomm_number_section',""); ?>" type="text" placeholder="<?php print_lang('enter_recomm_number_section'); ?>"  name="Recomm_number_section"  class="form-control " />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group ">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <label class="control-label" for="Recommendation_extracted_from_Source"><?php print_lang('recommendation_extracted_from_source'); ?> </label>
                                                            </div>
                                                            <div class="col-sm-8">
                                                                <div class="">
                                                                    <textarea placeholder="<?php print_lang('enter_recommendation_extracted_from_source'); ?>" id="ctrl-Recommendation_extracted_from_Source"  rows="5" name="Recommendation_extracted_from_Source" class=" form-control"><?php  echo $this->set_field_value('Recommendation_extracted_from_Source',""); ?></textarea>
                                                                    <!--<div class="invalid-feedback animated bounceIn text-center"><?php print_lang('please_enter_text'); ?></div>-->
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group ">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <label class="control-label" for="web_link"><?php print_lang('web_link'); ?> </label>
                                                            </div>
                                                            <div class="col-sm-8">
                                                                <div class="">
                                                                    <select  id="ctrl-web_link" name="web_link"  placeholder="<?php print_lang('select_a_value_'); ?>"    class="custom-select" >
                                                                        <option value=""><?php print_lang('select_a_value_'); ?></option>
                                                                        <?php 
                                                                        $web_link_options = $comp_model -> dcms_web_link_option_list();
                                                                        if(!empty($web_link_options)){
                                                                        foreach($web_link_options as $option){
                                                                        $value = (!empty($option['value']) ? $option['value'] : null);
                                                                        $label = (!empty($option['label']) ? $option['label'] : $value);
                                                                        $selected = $this->set_field_selected('web_link',$value, "");
                                                                        ?>
                                                                        <option <?php echo $selected; ?> value="<?php echo $value; ?>">
                                                                            <?php echo $label; ?>
                                                                        </option>
                                                                        <?php
                                                                        }
                                                                        }
                                                                        ?>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group ">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <label class="control-label" for="notes"><?php print_lang('notes'); ?> </label>
                                                            </div>
                                                            <div class="col-sm-8">
                                                                <div class="">
                                                                    <textarea placeholder="<?php print_lang('enter_notes'); ?>" id="ctrl-notes"  rows="5" name="notes" class=" form-control"><?php  echo $this->set_field_value('notes',""); ?></textarea>
                                                                    <!--<div class="invalid-feedback animated bounceIn text-center"><?php print_lang('please_enter_text'); ?></div>-->
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group ">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <label class="control-label" for="Added_at_version"><?php print_lang('added_at_version'); ?> </label>
                                                            </div>
                                                            <div class="col-sm-8">
                                                                <div class="">
                                                                    <input id="ctrl-Added_at_version"  value="<?php  echo $this->set_field_value('Added_at_version',""); ?>" type="number" placeholder="<?php print_lang('enter_added_at_version'); ?>" step="1"  name="Added_at_version"  class="form-control " />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group form-submit-btn-holder text-center mt-3">
                                                        <div class="form-ajax-status"></div>
                                                        <button class="btn btn-primary" type="submit">
                                                            <?php print_lang('submit'); ?>
                                                            <i class="fa fa-send"></i>
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
