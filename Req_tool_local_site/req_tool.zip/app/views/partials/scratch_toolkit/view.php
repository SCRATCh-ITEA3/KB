<?php
$comp_model = new SharedController;
$page_element_id = "view-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data Information from Controller
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id; //Page id from url
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_edit_btn = $this->show_edit_btn;
$show_delete_btn = $this->show_delete_btn;
$show_export_btn = $this->show_export_btn;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="view"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title"><?php print_lang('view_scratch_toolkit'); ?></h4>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <div  class="">
        <div class="container">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="card animated fadeIn page-content">
                        <?php
                        $counter = 0;
                        if(!empty($data)){
                        $rec_id = (!empty($data['toolkit_id']) ? urlencode($data['toolkit_id']) : null);
                        $counter++;
                        ?>
                        <div id="page-report-body" class="">
                            <table class="table table-hover table-borderless table-striped">
                                <!-- Table Body Start -->
                                <tbody class="page-data" id="page-data-<?php echo $page_element_id; ?>">
                                    <tr  class="td-toolkit_id">
                                        <th class="title"> <?php print_lang('toolkit_id'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['toolkit_id']; ?>" 
                                                data-pk="<?php echo $data['toolkit_id'] ?>" 
                                                data-url="<?php print_link("scratch_toolkit/editfield/" . urlencode($data['toolkit_id'])); ?>" 
                                                data-name="toolkit_id" 
                                                data-title="Enter Toolkit Id" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['toolkit_id']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-phase_devops">
                                        <th class="title"> <?php print_lang('phase_devops'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['phase_devops']; ?>" 
                                                data-pk="<?php echo $data['toolkit_id'] ?>" 
                                                data-url="<?php print_link("scratch_toolkit/editfield/" . urlencode($data['toolkit_id'])); ?>" 
                                                data-name="phase_devops" 
                                                data-title="Enter Phase Devops" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['phase_devops']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-toolkit_name">
                                        <th class="title"> <?php print_lang('toolkit_name'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['toolkit_name']; ?>" 
                                                data-pk="<?php echo $data['toolkit_id'] ?>" 
                                                data-url="<?php print_link("scratch_toolkit/editfield/" . urlencode($data['toolkit_id'])); ?>" 
                                                data-name="toolkit_name" 
                                                data-title="Enter Toolkit Name" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['toolkit_name']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-tool_example">
                                        <th class="title"> <?php print_lang('tool_example'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['tool_example']; ?>" 
                                                data-pk="<?php echo $data['toolkit_id'] ?>" 
                                                data-url="<?php print_link("scratch_toolkit/editfield/" . urlencode($data['toolkit_id'])); ?>" 
                                                data-name="tool_example" 
                                                data-title="Enter Tool Example" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['tool_example']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-tool_purpose">
                                        <th class="title"> <?php print_lang('tool_purpose'); ?>: </th>
                                        <td class="value">
                                            <span  data-pk="<?php echo $data['toolkit_id'] ?>" 
                                                data-url="<?php print_link("scratch_toolkit/editfield/" . urlencode($data['toolkit_id'])); ?>" 
                                                data-name="tool_purpose" 
                                                data-title="Enter Tool Purpose" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="textarea" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['tool_purpose']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-input">
                                        <th class="title"> <?php print_lang('input'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['input']; ?>" 
                                                data-pk="<?php echo $data['toolkit_id'] ?>" 
                                                data-url="<?php print_link("scratch_toolkit/editfield/" . urlencode($data['toolkit_id'])); ?>" 
                                                data-name="input" 
                                                data-title="Enter Input" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['input']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-action">
                                        <th class="title"> <?php print_lang('action'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['action']; ?>" 
                                                data-pk="<?php echo $data['toolkit_id'] ?>" 
                                                data-url="<?php print_link("scratch_toolkit/editfield/" . urlencode($data['toolkit_id'])); ?>" 
                                                data-name="action" 
                                                data-title="Enter Action" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['action']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-output">
                                        <th class="title"> <?php print_lang('output'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['output']; ?>" 
                                                data-pk="<?php echo $data['toolkit_id'] ?>" 
                                                data-url="<?php print_link("scratch_toolkit/editfield/" . urlencode($data['toolkit_id'])); ?>" 
                                                data-name="output" 
                                                data-title="Enter Output" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['output']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-tool_interface">
                                        <th class="title"> <?php print_lang('tool_interface'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['tool_interface']; ?>" 
                                                data-pk="<?php echo $data['toolkit_id'] ?>" 
                                                data-url="<?php print_link("scratch_toolkit/editfield/" . urlencode($data['toolkit_id'])); ?>" 
                                                data-name="tool_interface" 
                                                data-title="Enter Tool Interface" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['tool_interface']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-standards_guidelines">
                                        <th class="title"> <?php print_lang('standards_guidelines'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['standards_guidelines']; ?>" 
                                                data-pk="<?php echo $data['toolkit_id'] ?>" 
                                                data-url="<?php print_link("scratch_toolkit/editfield/" . urlencode($data['toolkit_id'])); ?>" 
                                                data-name="standards_guidelines" 
                                                data-title="Enter Standards Guidelines" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['standards_guidelines']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-scratch_req_addressed">
                                        <th class="title"> <?php print_lang('scratch_req_addressed'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['scratch_req_addressed']; ?>" 
                                                data-pk="<?php echo $data['toolkit_id'] ?>" 
                                                data-url="<?php print_link("scratch_toolkit/editfield/" . urlencode($data['toolkit_id'])); ?>" 
                                                data-name="scratch_req_addressed" 
                                                data-title="Enter Scratch Req Addressed" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['scratch_req_addressed']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-expectations">
                                        <th class="title"> <?php print_lang('expectations'); ?>: </th>
                                        <td class="value">
                                            <span  data-pk="<?php echo $data['toolkit_id'] ?>" 
                                                data-url="<?php print_link("scratch_toolkit/editfield/" . urlencode($data['toolkit_id'])); ?>" 
                                                data-name="expectations" 
                                                data-title="Enter Expectations" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="textarea" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['expectations']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-responsible">
                                        <th class="title"> <?php print_lang('responsible'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['responsible']; ?>" 
                                                data-pk="<?php echo $data['toolkit_id'] ?>" 
                                                data-url="<?php print_link("scratch_toolkit/editfield/" . urlencode($data['toolkit_id'])); ?>" 
                                                data-name="responsible" 
                                                data-title="Enter Responsible" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['responsible']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-status">
                                        <th class="title"> <?php print_lang('status'); ?>: </th>
                                        <td class="value">
                                            <span  data-pk="<?php echo $data['toolkit_id'] ?>" 
                                                data-url="<?php print_link("scratch_toolkit/editfield/" . urlencode($data['toolkit_id'])); ?>" 
                                                data-name="status" 
                                                data-title="Enter Status" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="textarea" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['status']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-tool_file">
                                        <th class="title"> <?php print_lang('tool_file'); ?>: </th>
                                        <td class="value">
                                            <span  data-value="<?php echo $data['tool_file']; ?>" 
                                                data-pk="<?php echo $data['toolkit_id'] ?>" 
                                                data-url="<?php print_link("scratch_toolkit/editfield/" . urlencode($data['toolkit_id'])); ?>" 
                                                data-name="tool_file" 
                                                data-title="Browse..." 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="is-editable" >
                                                <?php echo $data['tool_file']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                                <!-- Table Body End -->
                            </table>
                        </div>
                        <div class="p-3 d-flex">
                            <div class="dropup export-btn-holder mx-1">
                                <button class="btn btn-sm btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fa fa-save"></i> <?php print_lang('export'); ?>
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <?php $export_print_link = $this->set_current_page_link(array('format' => 'print')); ?>
                                    <a class="dropdown-item export-link-btn" data-format="print" href="<?php print_link($export_print_link); ?>" target="_blank">
                                        <img src="<?php print_link('assets/images/print.png') ?>" class="mr-2" /> PRINT
                                        </a>
                                        <?php $export_pdf_link = $this->set_current_page_link(array('format' => 'pdf')); ?>
                                        <a class="dropdown-item export-link-btn" data-format="pdf" href="<?php print_link($export_pdf_link); ?>" target="_blank">
                                            <img src="<?php print_link('assets/images/pdf.png') ?>" class="mr-2" /> PDF
                                            </a>
                                            <?php $export_word_link = $this->set_current_page_link(array('format' => 'word')); ?>
                                            <a class="dropdown-item export-link-btn" data-format="word" href="<?php print_link($export_word_link); ?>" target="_blank">
                                                <img src="<?php print_link('assets/images/doc.png') ?>" class="mr-2" /> WORD
                                                </a>
                                                <?php $export_csv_link = $this->set_current_page_link(array('format' => 'csv')); ?>
                                                <a class="dropdown-item export-link-btn" data-format="csv" href="<?php print_link($export_csv_link); ?>" target="_blank">
                                                    <img src="<?php print_link('assets/images/csv.png') ?>" class="mr-2" /> CSV
                                                    </a>
                                                    <?php $export_excel_link = $this->set_current_page_link(array('format' => 'excel')); ?>
                                                    <a class="dropdown-item export-link-btn" data-format="excel" href="<?php print_link($export_excel_link); ?>" target="_blank">
                                                        <img src="<?php print_link('assets/images/xsl.png') ?>" class="mr-2" /> EXCEL
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                            }
                                            else{
                                            ?>
                                            <!-- Empty Record Message -->
                                            <div class="text-muted p-3">
                                                <i class="fa fa-ban"></i> <?php print_lang('no_record_found'); ?>
                                            </div>
                                            <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
