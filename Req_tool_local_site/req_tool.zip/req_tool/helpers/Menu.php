<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbarsideleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => ''
		),
		
		array(
			'path' => 'iot_protocol_list', 
			'label' => 'Iot Protocol List', 
			'icon' => ''
		),
		
		array(
			'path' => 'Standards', 
			'label' => 'Standards', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'etsi_consumer_sec', 
			'label' => 'ETSI Consumer Sec', 
			'icon' => ''
		),
		
		array(
			'path' => 'dcms', 
			'label' => 'DCMS Mapping Security & Privacy in the Internet of Things', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'dcm_owasp_top10_map', 
			'label' => 'Dcm Owasp Top10 Mapping', 
			'icon' => ''
		),
		
		array(
			'path' => 'dcms_all_org', 
			'label' => 'Dcms All Organizations listed', 
			'icon' => ''
		),
		
		array(
			'path' => 'dcms_code', 
			'label' => 'Dcms main Code of practice', 
			'icon' => ''
		),
		
		array(
			'path' => 'dcms/filter', 
			'label' => 'DCMS inventarisation of standards', 
			'icon' => ''
		),
		
		array(
			'path' => 'org_weblink', 
			'label' => 'Link to web pages listed standards', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'iotsf_req_v2', 
			'label' => 'Iotsf Req V2', 
			'icon' => ''
		),
		
		array(
			'path' => 'iot_a_uni', 
			'label' => 'Iot A Uni', 
			'icon' => ''
		),
		
		array(
			'path' => 'Standards', 
			'label' => 'OWASP', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'owasp_top10', 
			'label' => 'Owasp Top10', 
			'icon' => ''
		),
		
		array(
			'path' => 'owasp_isvs_1_0rc', 
			'label' => 'OWASP ISVS draft', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => '', 
			'label' => 'ENISA', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'enisa_industry_iot', 
			'label' => 'Enisa Industry Iot', 
			'icon' => ''
		)
	)
		)
	)
		),
		
		array(
			'path' => 'menu7', 
			'label' => 'architecture', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'architectural_principle', 
			'label' => 'Architectural Principle', 
			'icon' => ''
		),
		
		array(
			'path' => 'std_reference_arch', 
			'label' => 'Reference Architecture examples', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'ecso_sota', 
			'label' => 'Ecso Sota', 
			'icon' => ''
		),
		
		array(
			'path' => 'dcms_code', 
			'label' => 'dcms v2', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'test_map/Index', 
			'label' => 'Test Map', 
			'icon' => ''
		),
		
		array(
			'path' => 'test_map/list2', 
			'label' => 'List2', 
			'icon' => ''
		),
		
		array(
			'path' => 'dcms_code/list2', 
			'label' => 'View2', 
			'icon' => ''
		),
		
		array(
			'path' => 'dcms_code/add2', 
			'label' => 'Add2', 
			'icon' => ''
		),
		
		array(
			'path' => 'dcms_code/add3', 
			'label' => 'Add3', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'sebok_c', 
			'label' => 'Sebok C', 
			'icon' => ''
		)
	);
		
			public static $navbartopleft = array(
		array(
			'path' => 'scratch_requirement', 
			'label' => 'Scratch Requirement', 
			'icon' => ''
		),
		
		array(
			'path' => 'scratch_usecase', 
			'label' => 'Scratch Usecase', 
			'icon' => ''
		),
		
		array(
			'path' => 'scratch_toolkit/list2', 
			'label' => 'SCRATCh tools', 
			'icon' => ''
		),
		
		array(
			'path' => 'scratch_usecase_scen', 
			'label' => 'Scratch Usecase Scen', 
			'icon' => ''
		)
	);
		
			public static $navbartopright = array(
		array(
			'path' => 'enisa_req', 
			'label' => 'ENISA__________________________', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'enisa_req', 
			'label' => 'Requirements', 
			'icon' => ''
		),
		
		array(
			'path' => 'enisa_threats', 
			'label' => 'Threats', 
			'icon' => ''
		),
		
		array(
			'path' => 'enisa_sec_domain', 
			'label' => 'Security Domains', 
			'icon' => ''
		),
		
		array(
			'path' => 'enisa_good_practices', 
			'label' => 'Good Practices', 
			'icon' => ''
		),
		
		array(
			'path' => 'enisa_iot_assets', 
			'label' => 'Iot Assets', 
			'icon' => ''
		)
	)
		)
	);
		
	
	
			public static $use_case = array(
		array(
			"value" => "Retail", 
			"label" => "Retail", 
		),
		array(
			"value" => "Police", 
			"label" => "Police", 
		),
		array(
			"value" => "Smartgrid", 
			"label" => "Smartgrid", 
		),
		array(
			"value" => "Smart machine", 
			"label" => "Smart machine", 
		),);
		
			public static $role = array(
		array(
			"value" => "Administrator", 
			"label" => "Administrator", 
		),
		array(
			"value" => "User", 
			"label" => "User", 
		),);
		
}