<div class="container">
	<h4><?php print_lang('email_verification_completed_'); ?></h4>
	<hr />
	<div class="">
		<a href="<?php print_link('index') ?>" class="btn btn-primary"><?php print_lang('continue'); ?></a>
	</div>
</div>



