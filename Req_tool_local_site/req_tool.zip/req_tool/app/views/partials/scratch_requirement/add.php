<?php
$comp_model = new SharedController;
$page_element_id = "add-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
$show_header = $this->show_header;
$view_title = $this->view_title;
$redirect_to = $this->redirect_to;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="add"  data-display-type="" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title"><?php print_lang('add_new_scratch_requirement'); ?></h4>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <div  class="">
        <div class="container">
            <div class="row ">
                <div class="col-md-7 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="bg-light p-3 animated fadeIn page-content">
                        <form id="scratch_requirement-add-form" role="form" novalidate enctype="multipart/form-data" class="form page-form form-horizontal needs-validation" action="<?php print_link("scratch_requirement/add?csrf_token=$csrf_token") ?>" method="post">
                            <div>
                                <div class="form-group ">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <label class="control-label" for="short_d"><?php print_lang('short_d'); ?> </label>
                                        </div>
                                        <div class="col-sm-8">
                                            <div class="">
                                                <input id="ctrl-short_d"  value="<?php  echo $this->set_field_value('short_d',"short desc"); ?>" type="text" placeholder="<?php print_lang('enter_short_d'); ?>"  name="short_d"  class="form-control " />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label class="control-label" for="tags_goodpractices"><?php print_lang('tags_goodpractices'); ?> </label>
                                            </div>
                                            <div class="col-sm-8">
                                                <div class="">
                                                    <input id="ctrl-tags_goodpractices"  value="<?php  echo $this->set_field_value('tags_goodpractices',""); ?>" type="text" placeholder="<?php print_lang('enter_tags_goodpractices'); ?>"  name="tags_goodpractices"  class="form-control " />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <div class="row">
                                                <div class="col-sm-4">
                                                    <label class="control-label" for="applies_to_asset_group"><?php print_lang('applies_to_asset_group'); ?> </label>
                                                </div>
                                                <div class="col-sm-8">
                                                    <div class="">
                                                        <input id="ctrl-applies_to_asset_group"  value="<?php  echo $this->set_field_value('applies_to_asset_group',""); ?>" type="text" placeholder="<?php print_lang('enter_applies_to_asset_group'); ?>"  name="applies_to_asset_group"  class="form-control " />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group ">
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <label class="control-label" for="applies_to_asset"><?php print_lang('applies_to_asset'); ?> </label>
                                                    </div>
                                                    <div class="col-sm-8">
                                                        <div class="">
                                                            <input id="ctrl-applies_to_asset"  value="<?php  echo $this->set_field_value('applies_to_asset',""); ?>" type="text" placeholder="<?php print_lang('enter_applies_to_asset'); ?>"  name="applies_to_asset"  class="form-control " />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group ">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <label class="control-label" for="use_case"><?php print_lang('use_case'); ?> </label>
                                                        </div>
                                                        <div class="col-sm-8">
                                                            <div class="">
                                                                <input id="ctrl-use_case"  value="<?php  echo $this->set_field_value('use_case',""); ?>" type="text" placeholder="<?php print_lang('enter_use_case'); ?>"  name="use_case"  class="form-control " />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group ">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <label class="control-label" for="scenario"><?php print_lang('scenario'); ?> </label>
                                                            </div>
                                                            <div class="col-sm-8">
                                                                <div class="">
                                                                    <input id="ctrl-scenario"  value="<?php  echo $this->set_field_value('scenario',""); ?>" type="number" placeholder="<?php print_lang('enter_scenario'); ?>" step="1"  name="scenario"  class="form-control " />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group ">
                                                            <div class="row">
                                                                <div class="col-sm-4">
                                                                    <label class="control-label" for="depends_on"><?php print_lang('depends_on'); ?> </label>
                                                                </div>
                                                                <div class="col-sm-8">
                                                                    <div class="">
                                                                        <input id="ctrl-depends_on"  value="<?php  echo $this->set_field_value('depends_on',""); ?>" type="text" placeholder="<?php print_lang('enter_depends_on'); ?>"  name="depends_on"  class="form-control " />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group ">
                                                                <div class="row">
                                                                    <div class="col-sm-4">
                                                                        <label class="control-label" for="status"><?php print_lang('status'); ?> </label>
                                                                    </div>
                                                                    <div class="col-sm-8">
                                                                        <div class="">
                                                                            <input id="ctrl-status"  value="<?php  echo $this->set_field_value('status',""); ?>" type="text" placeholder="<?php print_lang('enter_status'); ?>"  name="status"  class="form-control " />
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group ">
                                                                    <div class="row">
                                                                        <div class="col-sm-4">
                                                                            <label class="control-label" for="description"><?php print_lang('description'); ?> </label>
                                                                        </div>
                                                                        <div class="col-sm-8">
                                                                            <div class="">
                                                                                <textarea placeholder="<?php print_lang('enter_description'); ?>" id="ctrl-description"  rows="5" name="description" class=" form-control"><?php  echo $this->set_field_value('description',""); ?></textarea>
                                                                                <!--<div class="invalid-feedback animated bounceIn text-center"><?php print_lang('please_enter_text'); ?></div>-->
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group ">
                                                                    <div class="row">
                                                                        <div class="col-sm-4">
                                                                            <label class="control-label" for="rationale"><?php print_lang('rationale'); ?> </label>
                                                                        </div>
                                                                        <div class="col-sm-8">
                                                                            <div class="">
                                                                                <textarea placeholder="<?php print_lang('enter_rationale'); ?>" id="ctrl-rationale"  rows="5" name="rationale" class=" form-control"><?php  echo $this->set_field_value('rationale',""); ?></textarea>
                                                                                <!--<div class="invalid-feedback animated bounceIn text-center"><?php print_lang('please_enter_text'); ?></div>-->
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group ">
                                                                    <div class="row">
                                                                        <div class="col-sm-4">
                                                                            <label class="control-label" for="acceptance_c"><?php print_lang('acceptance_c'); ?> </label>
                                                                        </div>
                                                                        <div class="col-sm-8">
                                                                            <div class="">
                                                                                <textarea placeholder="<?php print_lang('enter_acceptance_c'); ?>" id="ctrl-acceptance_c"  rows="5" name="acceptance_c" class=" form-control"><?php  echo $this->set_field_value('acceptance_c',""); ?></textarea>
                                                                                <!--<div class="invalid-feedback animated bounceIn text-center"><?php print_lang('please_enter_text'); ?></div>-->
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group ">
                                                                    <div class="row">
                                                                        <div class="col-sm-4">
                                                                            <label class="control-label" for="sebok_c"><?php print_lang('sebok_c'); ?> </label>
                                                                        </div>
                                                                        <div class="col-sm-8">
                                                                            <div class="">
                                                                                <input id="ctrl-sebok_c"  value="<?php  echo $this->set_field_value('sebok_c',""); ?>" type="text" placeholder="<?php print_lang('enter_sebok_c'); ?>"  name="sebok_c"  class="form-control " />
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group ">
                                                                        <div class="row">
                                                                            <div class="col-sm-4">
                                                                                <label class="control-label" for="priority"><?php print_lang('priority'); ?> </label>
                                                                            </div>
                                                                            <div class="col-sm-8">
                                                                                <div class="">
                                                                                    <input id="ctrl-priority"  value="<?php  echo $this->set_field_value('priority',"low"); ?>" type="text" placeholder="<?php print_lang('enter_priority'); ?>"  name="priority"  class="form-control " />
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group ">
                                                                            <div class="row">
                                                                                <div class="col-sm-4">
                                                                                    <label class="control-label" for="remarks"><?php print_lang('remarks'); ?> </label>
                                                                                </div>
                                                                                <div class="col-sm-8">
                                                                                    <div class="">
                                                                                        <input id="ctrl-remarks"  value="<?php  echo $this->set_field_value('remarks',""); ?>" type="text" placeholder="<?php print_lang('enter_remarks'); ?>"  name="remarks"  class="form-control " />
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group ">
                                                                                <div class="row">
                                                                                    <div class="col-sm-4">
                                                                                        <label class="control-label" for="company"><?php print_lang('company'); ?> </label>
                                                                                    </div>
                                                                                    <div class="col-sm-8">
                                                                                        <div class="">
                                                                                            <input id="ctrl-company"  value="<?php  echo $this->set_field_value('company',""); ?>" type="text" placeholder="<?php print_lang('enter_company'); ?>"  name="company"  class="form-control " />
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group form-submit-btn-holder text-center mt-3">
                                                                                <div class="form-ajax-status"></div>
                                                                                <button class="btn btn-primary" type="submit">
                                                                                    <?php print_lang('submit'); ?>
                                                                                    <i class="fa fa-send"></i>
                                                                                </button>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </section>
