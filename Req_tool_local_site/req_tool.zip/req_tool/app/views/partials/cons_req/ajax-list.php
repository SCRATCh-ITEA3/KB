<?php
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
$field_name = $this->route->field_name;
$field_value = $this->route->field_value;
$view_data = $this->view_data;
$records = $view_data->records;
$record_count = $view_data->record_count;
$total_records = $view_data->total_records;
if (!empty($records)) {
?>
<!--record-->
<?php
$counter = 0;
foreach($records as $data){
$rec_id = (!empty($data['unique_nr']) ? urlencode($data['unique_nr']) : null);
$counter++;
?>
<tr>
    <th class="td-sno"><?php echo $counter; ?></th>
    <td class="td-standard">
        <span  data-value="<?php echo $data['standard']; ?>" 
            data-pk="<?php echo $data['unique_nr'] ?>" 
            data-url="<?php print_link("cons_req/editfield/" . urlencode($data['unique_nr'])); ?>" 
            data-name="standard" 
            data-title="Enter Standard" 
            data-placement="left" 
            data-toggle="click" 
            data-type="text" 
            data-mode="popover" 
            data-showbuttons="left" 
            class="is-editable" >
            <?php echo $data['standard']; ?> 
        </span>
    </td>
    <td class="td-type_req">
        <span  data-value="<?php echo $data['type_req']; ?>" 
            data-pk="<?php echo $data['unique_nr'] ?>" 
            data-url="<?php print_link("cons_req/editfield/" . urlencode($data['unique_nr'])); ?>" 
            data-name="type_req" 
            data-title="Enter Type Req" 
            data-placement="left" 
            data-toggle="click" 
            data-type="text" 
            data-mode="popover" 
            data-showbuttons="left" 
            class="is-editable" >
            <?php echo $data['type_req']; ?> 
        </span>
    </td>
    <td class="td-req_nr">
        <span  data-value="<?php echo $data['req_nr']; ?>" 
            data-pk="<?php echo $data['unique_nr'] ?>" 
            data-url="<?php print_link("cons_req/editfield/" . urlencode($data['unique_nr'])); ?>" 
            data-name="req_nr" 
            data-title="Enter Req Nr" 
            data-placement="left" 
            data-toggle="click" 
            data-type="text" 
            data-mode="popover" 
            data-showbuttons="left" 
            class="is-editable" >
            <?php echo $data['req_nr']; ?> 
        </span>
    </td>
    <td class="td-description">
        <span  data-pk="<?php echo $data['unique_nr'] ?>" 
            data-url="<?php print_link("cons_req/editfield/" . urlencode($data['unique_nr'])); ?>" 
            data-name="description" 
            data-title="Enter Description" 
            data-placement="left" 
            data-toggle="click" 
            data-type="textarea" 
            data-mode="popover" 
            data-showbuttons="left" 
            class="is-editable" >
            <?php echo $data['description']; ?> 
        </span>
    </td>
    <td class="td-prim_keyw">
        <span  data-value="<?php echo $data['prim_keyw']; ?>" 
            data-pk="<?php echo $data['unique_nr'] ?>" 
            data-url="<?php print_link("cons_req/editfield/" . urlencode($data['unique_nr'])); ?>" 
            data-name="prim_keyw" 
            data-title="Enter Prim Keyw" 
            data-placement="left" 
            data-toggle="click" 
            data-type="text" 
            data-mode="popover" 
            data-showbuttons="left" 
            class="is-editable" >
            <?php echo $data['prim_keyw']; ?> 
        </span>
    </td>
    <td class="td-threats">
        <span  data-value="<?php echo $data['threats']; ?>" 
            data-pk="<?php echo $data['unique_nr'] ?>" 
            data-url="<?php print_link("cons_req/editfield/" . urlencode($data['unique_nr'])); ?>" 
            data-name="threats" 
            data-title="Enter Threats" 
            data-placement="left" 
            data-toggle="click" 
            data-type="text" 
            data-mode="popover" 
            data-showbuttons="left" 
            class="is-editable" >
            <?php echo $data['threats']; ?> 
        </span>
    </td>
    <th class="td-btn">
        <a class="btn btn-sm btn-success has-tooltip page-modal" title="<?php print_lang('view_record'); ?>" href="<?php print_link("cons_req/view/$rec_id"); ?>">
            <i class="fa fa-eye"></i> <?php print_lang('v'); ?>
        </a>
    </th>
</tr>
<?php 
}
?>
<?php
} else {
?>
<td class="no-record-found col-12" colspan="100">
    <h4 class="text-muted text-center ">
        <?php print_lang('no_record_found'); ?>
    </h4>
</td>
<?php
}
?>
