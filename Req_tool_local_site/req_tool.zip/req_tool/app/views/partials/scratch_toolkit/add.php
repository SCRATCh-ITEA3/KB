<?php
$comp_model = new SharedController;
$page_element_id = "add-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
$show_header = $this->show_header;
$view_title = $this->view_title;
$redirect_to = $this->redirect_to;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="add"  data-display-type="" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title"><?php print_lang('add_new_scratch_toolkit'); ?></h4>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <div  class="">
        <div class="container">
            <div class="row ">
                <div class="col-md-7 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="bg-light p-3 animated fadeIn page-content">
                        <form id="scratch_toolkit-add-form" role="form" novalidate enctype="multipart/form-data" class="form page-form form-horizontal needs-validation" action="<?php print_link("scratch_toolkit/add?csrf_token=$csrf_token") ?>" method="post">
                            <div>
                                <div class="form-group ">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <label class="control-label" for="toolkit_id"><?php print_lang('toolkit_id'); ?> </label>
                                        </div>
                                        <div class="col-sm-8">
                                            <div class="">
                                                <input id="ctrl-toolkit_id"  value="<?php  echo $this->set_field_value('toolkit_id',""); ?>" type="text" placeholder="<?php print_lang('enter_toolkit_id'); ?>"  name="toolkit_id"  class="form-control " />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label class="control-label" for="phase_devops"><?php print_lang('phase_devops'); ?> </label>
                                            </div>
                                            <div class="col-sm-8">
                                                <div class="">
                                                    <input id="ctrl-phase_devops"  value="<?php  echo $this->set_field_value('phase_devops',""); ?>" type="text" placeholder="<?php print_lang('enter_phase_devops'); ?>"  name="phase_devops"  class="form-control " />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <div class="row">
                                                <div class="col-sm-4">
                                                    <label class="control-label" for="toolkit_name"><?php print_lang('toolkit_name'); ?> </label>
                                                </div>
                                                <div class="col-sm-8">
                                                    <div class="">
                                                        <input id="ctrl-toolkit_name"  value="<?php  echo $this->set_field_value('toolkit_name',""); ?>" type="text" placeholder="<?php print_lang('enter_toolkit_name'); ?>"  name="toolkit_name"  class="form-control " />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group ">
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <label class="control-label" for="tool_example"><?php print_lang('tool_example'); ?> </label>
                                                    </div>
                                                    <div class="col-sm-8">
                                                        <div class="">
                                                            <input id="ctrl-tool_example"  value="<?php  echo $this->set_field_value('tool_example',""); ?>" type="text" placeholder="<?php print_lang('enter_tool_example'); ?>"  name="tool_example"  class="form-control " />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group ">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <label class="control-label" for="tool_purpose"><?php print_lang('tool_purpose'); ?> </label>
                                                        </div>
                                                        <div class="col-sm-8">
                                                            <div class="">
                                                                <textarea placeholder="<?php print_lang('enter_tool_purpose'); ?>" id="ctrl-tool_purpose"  rows="5" name="tool_purpose" class=" form-control"><?php  echo $this->set_field_value('tool_purpose',""); ?></textarea>
                                                                <!--<div class="invalid-feedback animated bounceIn text-center"><?php print_lang('please_enter_text'); ?></div>-->
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group ">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <label class="control-label" for="input"><?php print_lang('input'); ?> </label>
                                                        </div>
                                                        <div class="col-sm-8">
                                                            <div class="">
                                                                <input id="ctrl-input"  value="<?php  echo $this->set_field_value('input',""); ?>" type="text" placeholder="<?php print_lang('enter_input'); ?>"  name="input"  class="form-control " />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group ">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <label class="control-label" for="action"><?php print_lang('action'); ?> </label>
                                                            </div>
                                                            <div class="col-sm-8">
                                                                <div class="">
                                                                    <input id="ctrl-action"  value="<?php  echo $this->set_field_value('action',""); ?>" type="text" placeholder="<?php print_lang('enter_action'); ?>"  name="action"  class="form-control " />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group ">
                                                            <div class="row">
                                                                <div class="col-sm-4">
                                                                    <label class="control-label" for="output"><?php print_lang('output'); ?> </label>
                                                                </div>
                                                                <div class="col-sm-8">
                                                                    <div class="">
                                                                        <input id="ctrl-output"  value="<?php  echo $this->set_field_value('output',""); ?>" type="text" placeholder="<?php print_lang('enter_output'); ?>"  name="output"  class="form-control " />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group ">
                                                                <div class="row">
                                                                    <div class="col-sm-4">
                                                                        <label class="control-label" for="tool_interface"><?php print_lang('tool_interface'); ?> </label>
                                                                    </div>
                                                                    <div class="col-sm-8">
                                                                        <div class="">
                                                                            <input id="ctrl-tool_interface"  value="<?php  echo $this->set_field_value('tool_interface',""); ?>" type="text" placeholder="<?php print_lang('enter_tool_interface'); ?>"  name="tool_interface"  class="form-control " />
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group ">
                                                                    <div class="row">
                                                                        <div class="col-sm-4">
                                                                            <label class="control-label" for="standards_guidelines"><?php print_lang('standards_guidelines'); ?> </label>
                                                                        </div>
                                                                        <div class="col-sm-8">
                                                                            <div class="">
                                                                                <input id="ctrl-standards_guidelines"  value="<?php  echo $this->set_field_value('standards_guidelines',""); ?>" type="text" placeholder="<?php print_lang('enter_standards_guidelines'); ?>"  name="standards_guidelines"  class="form-control " />
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group ">
                                                                        <div class="row">
                                                                            <div class="col-sm-4">
                                                                                <label class="control-label" for="scratch_req_addressed"><?php print_lang('scratch_req_addressed'); ?> </label>
                                                                            </div>
                                                                            <div class="col-sm-8">
                                                                                <div class="">
                                                                                    <input id="ctrl-scratch_req_addressed"  value="<?php  echo $this->set_field_value('scratch_req_addressed',""); ?>" type="text" placeholder="<?php print_lang('enter_scratch_req_addressed'); ?>"  name="scratch_req_addressed"  class="form-control " />
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group ">
                                                                            <div class="row">
                                                                                <div class="col-sm-4">
                                                                                    <label class="control-label" for="expectations"><?php print_lang('expectations'); ?> </label>
                                                                                </div>
                                                                                <div class="col-sm-8">
                                                                                    <div class="">
                                                                                        <textarea placeholder="<?php print_lang('enter_expectations'); ?>" id="ctrl-expectations"  rows="5" name="expectations" class=" form-control"><?php  echo $this->set_field_value('expectations',""); ?></textarea>
                                                                                        <!--<div class="invalid-feedback animated bounceIn text-center"><?php print_lang('please_enter_text'); ?></div>-->
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group ">
                                                                            <div class="row">
                                                                                <div class="col-sm-4">
                                                                                    <label class="control-label" for="responsible"><?php print_lang('responsible'); ?> </label>
                                                                                </div>
                                                                                <div class="col-sm-8">
                                                                                    <div class="">
                                                                                        <input id="ctrl-responsible"  value="<?php  echo $this->set_field_value('responsible',""); ?>" type="text" placeholder="<?php print_lang('enter_responsible'); ?>"  name="responsible"  class="form-control " />
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group ">
                                                                                <div class="row">
                                                                                    <div class="col-sm-4">
                                                                                        <label class="control-label" for="status"><?php print_lang('status'); ?> </label>
                                                                                    </div>
                                                                                    <div class="col-sm-8">
                                                                                        <div class="">
                                                                                            <textarea placeholder="<?php print_lang('enter_status'); ?>" id="ctrl-status"  rows="5" name="status" class=" form-control"><?php  echo $this->set_field_value('status',""); ?></textarea>
                                                                                            <!--<div class="invalid-feedback animated bounceIn text-center"><?php print_lang('please_enter_text'); ?></div>-->
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group ">
                                                                                <div class="row">
                                                                                    <div class="col-sm-4">
                                                                                        <label class="control-label" for="tool_file"><?php print_lang('tool_file'); ?> </label>
                                                                                    </div>
                                                                                    <div class="col-sm-8">
                                                                                        <div class="">
                                                                                            <div class="dropzone " input="#ctrl-tool_file" fieldname="tool_file"    data-multiple="false" dropmsg="<?php print_lang('choose_files_or_drag_and_drop_files_to_upload'); ?>"    btntext="<?php print_lang('browse'); ?>" filesize="3" maximum="1">
                                                                                                <input name="tool_file" id="ctrl-tool_file" class="dropzone-input form-control" value="<?php  echo $this->set_field_value('tool_file',""); ?>" type="text"  />
                                                                                                    <!--<div class="invalid-feedback animated bounceIn text-center"><?php print_lang('please_a_choose_file'); ?></div>-->
                                                                                                    <div class="dz-file-limit animated bounceIn text-center text-danger"></div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group form-submit-btn-holder text-center mt-3">
                                                                                <div class="form-ajax-status"></div>
                                                                                <button class="btn btn-primary" type="submit">
                                                                                    <?php print_lang('submit'); ?>
                                                                                    <i class="fa fa-send"></i>
                                                                                </button>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </section>
